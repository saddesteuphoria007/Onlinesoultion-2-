<?php

$conn = mysqli_connect('localhost','root','','tuckshop') or die('connection failed');

?>